define(
"dijit/form/nls/tr/ComboBox", ({
		previousMessage: "Önceki seçenekler",
		nextMessage: "Diğer seçenekler"
})
);
