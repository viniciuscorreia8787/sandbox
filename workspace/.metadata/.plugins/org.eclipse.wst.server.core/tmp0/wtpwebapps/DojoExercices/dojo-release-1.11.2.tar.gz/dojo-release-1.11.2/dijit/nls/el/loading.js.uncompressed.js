define(
"dijit/nls/el/loading", ({
	loadingState: "Φόρτωση...",
	errorState: "Σας ζητούμε συγνώμη, παρουσιάστηκε σφάλμα"
})
);
